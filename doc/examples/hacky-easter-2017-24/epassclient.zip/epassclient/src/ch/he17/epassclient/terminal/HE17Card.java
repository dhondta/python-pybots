package ch.he17.epassclient.terminal;

import java.io.IOException;
import java.net.Socket;

import javax.smartcardio.ATR;
import javax.smartcardio.Card;
import javax.smartcardio.CardChannel;
import javax.smartcardio.CardException;

public class HE17Card extends Card {

	private HE17Channel he17channel;

	public HE17Card(Socket socket) throws IOException {
		he17channel = new HE17Channel(this, socket);
	}

	@Override
	public ATR getATR() {
		byte[] atr = { 0x3B, (byte) 0x88, (byte) 0x80, 0x01, 0x00, 0x73, (byte) 0xC8, 0x40, 0x00, 0x00, (byte) 0x90,
				0x00, 0x62 };
		return new ATR(atr);
	}

	@Override
	public String getProtocol() {
		return "T=1";
	}

	@Override
	public CardChannel getBasicChannel() {
		return he17channel;
	}

	@Override
	public CardChannel openLogicalChannel() throws CardException {
		return null;
	}

	@Override
	public void beginExclusive() throws CardException {
	}

	@Override
	public void endExclusive() throws CardException {
	}

	@Override
	public byte[] transmitControlCommand(int controlCode, byte[] command) throws CardException {
		return null;
	}

	@Override
	public void disconnect(boolean reset) throws CardException {
	}
}

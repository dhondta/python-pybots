package ch.he17.epassclient.terminal;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.smartcardio.Card;
import javax.smartcardio.CardException;
import javax.smartcardio.CardTerminal;

public class HE17Terminal extends CardTerminal {

	@Override
	public String getName() {
		return "HackyEaster 2017 - Remote terminal provider";
	}

	@Override
	public Card connect(String protocol) throws CardException {
		try {
			return new HE17Card(new Socket("localhost", 7777));
		} catch (UnknownHostException e) {
			throw new CardException(e);
		} catch (IOException e) {
			throw new CardException(e);
		}
	}

	@Override
	public boolean isCardPresent() throws CardException {
		return true;
	}

	@Override
	public boolean waitForCardPresent(long timeout) throws CardException {
		return true;
	}

	@Override
	public boolean waitForCardAbsent(long timeout) throws CardException {
		return true;
	}
}

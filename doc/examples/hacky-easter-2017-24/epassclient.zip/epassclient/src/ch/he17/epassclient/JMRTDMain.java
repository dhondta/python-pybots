package ch.he17.epassclient;

import java.io.IOException;

import javax.smartcardio.CardException;
import javax.smartcardio.CardTerminal;

import org.jmrtd.PassportService;

import ch.he17.epassclient.terminal.HE17Terminal;
import net.sf.scuba.smartcards.CardService;
import net.sf.scuba.smartcards.CardServiceException;

public class JMRTDMain {

	public static void main(String[] args) throws CardServiceException, CardException, IOException {
		CardTerminal cardTerminal = new HE17Terminal();
		CardService cService = CardService.getInstance(cardTerminal);
		PassportService passService = new PassportService(cService);
		cardTerminal.waitForCardPresent(1000);

		passService.open();
		passService.sendSelectApplet(false);

		// your stuff here

	}
}

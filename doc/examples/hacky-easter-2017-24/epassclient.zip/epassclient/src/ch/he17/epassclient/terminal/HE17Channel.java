package ch.he17.epassclient.terminal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.ByteBuffer;

import javax.smartcardio.Card;
import javax.smartcardio.CardChannel;
import javax.smartcardio.CardException;
import javax.smartcardio.CommandAPDU;
import javax.smartcardio.ResponseAPDU;

import org.apache.commons.codec.binary.Hex;

public class HE17Channel extends CardChannel {
	PrintWriter out;
	BufferedReader in;
	Card card;
	Socket socket;

	public HE17Channel(Card card, Socket socket) throws IOException {
		this.card = card;
		this.socket = socket;
		out = new PrintWriter(socket.getOutputStream(), true);
		in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		// read welcome String
		System.out.println(in.readLine());
	}

	@Override
	public Card getCard() {
		return card;
	}

	@Override
	public int getChannelNumber() {
		return 0;
	}

	@Override
	public ResponseAPDU transmit(CommandAPDU command) throws CardException {
		String c = Hex.encodeHexString(command.getBytes());
		out.println(c);
		System.out.println("--> " + c);
		String r;
		try {
			r = in.readLine();
			System.out.println("<-- " + r);
			return new ResponseAPDU(Hex.decodeHex(r.toCharArray()));
		} catch (Exception e) {
			throw new CardException(e);
		}
	}

	@Override
	public int transmit(ByteBuffer command, ByteBuffer response) throws CardException {
		ResponseAPDU rapdu = transmit(new CommandAPDU(command));
		byte[] rapduBytes = rapdu.getBytes();
		response.put(rapduBytes);
		return rapduBytes.length;
	}

	@Override
	public void close() throws CardException {
		try {
			socket.close();
		} catch (Exception e) {
			throw new CardException(e);
		}
	}
}
